import java.util.*;
class demo
{
public static void main(String args[])
{
System.out.println("Hello World");
}
}